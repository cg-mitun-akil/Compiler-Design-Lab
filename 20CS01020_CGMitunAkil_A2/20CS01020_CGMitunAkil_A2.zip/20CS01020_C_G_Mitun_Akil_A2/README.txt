$g++ lexicalAnal.cpp
$./a.exe
Enter the statement: 
if input<10 then output1=100 else output2>=100
( Keyword       if )     
( Identifier    input )  
( Relop         < )      
( Number        10 )     
( Keyword       then )   
( Identifier    output1 )
( Relop         = )      
( Number        100 )    
( Keyword       else )   
( Identifier    output2 )
( Relop         >= )     
( Number        100 )