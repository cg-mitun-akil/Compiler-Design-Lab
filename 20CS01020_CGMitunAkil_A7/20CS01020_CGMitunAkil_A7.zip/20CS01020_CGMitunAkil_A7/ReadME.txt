1. Open console and run following commands:
    bison -d parse.y
    flex parse.l
    gcc parse.tab.c
    ./a.exe 
2. Give location of one of the examples
    ./examples/input_1.txt
    ./examples/input_2.txt
    ./examples/input_3.txt
3. Result in stdout
