Compile and Execute lr0.cpp and provide productions to get Parse table and Automata.
The DFA and Parse table for Question 1 is provided in q1.pdf file.